export enum CacheEnum {
  TOKEN_NAME = 'login_token',
  REDIRECT_ROUTE_NAME = 'redirect_router_name',
  HISTORY_MENU = 'history_menu',
}
