import './tailwindcss.css'
import { App } from 'vue'

const setup = (app: App) => {}
export { setup }
